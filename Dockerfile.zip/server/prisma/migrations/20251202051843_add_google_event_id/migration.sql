-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN "googleEventId" TEXT;
