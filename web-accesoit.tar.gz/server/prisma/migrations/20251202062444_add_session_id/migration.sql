-- AlterTable
ALTER TABLE "Appointment" ADD COLUMN "sessionId" TEXT;
